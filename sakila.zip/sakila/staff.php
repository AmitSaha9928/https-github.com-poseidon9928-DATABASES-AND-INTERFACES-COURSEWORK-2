<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
		<link href="css/style.css" rel="stylesheet">
    <title>Table with database</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: blue;
            font-family: monospace;
            font-size: 13.3px;
            text-align:center;
        }
        th{
            
            background-color: black;
            color :white;
            text-align: center;
        }
    </style>
</head>
<STYLE>A{text-decoration:none;}</STYLE>
<body>
<header> 
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
    <div class="container">


	
		
			<nav>
				<ul>
                
                    
					<li><a href="staff_query.php">QUERY</a></li>
					
				
					
					
				</ul>
			</nav>
        </div>
    </header>
<body>
<table>
        <tr>
            <th>staff_id</th>
            <th>first_name</th>
            <th>last_name</th>
            <th>address_id</th>
            <th>email</th>
            <th>store_id</th>
            <th>active</th>
            <th>username</th>
            <th>password</th>
            <th>last_update</th>
            <th>picture</th>
            
</tr>
<?php

//create connection
$conn= mysqli_connect("localhost","root","","sakila");

//check connection
if($conn->connect_error){
    die("Connection failed: ".$conn-> connect_error);
}

$sql= "SELECT staff_id,first_name,last_name,address_id,email,store_id,active,username1,password,last_update,picture FROM staff";
$result=$conn-> query($sql);

if($result-> num_rows > 0){
    //output data for each row
    while($row= $result-> fetch_assoc()){
        echo "<tr><td>". $row["staff_id"]. "</td><td>" .$row["first_name"]."</td><td>" . $row["last_name"]."</td><td>" .$row["address_id"]."</td><td>" . $row["email"]."</td><td>" . $row["store_id"]."</td><td>". $row["active"]."</td><td>" . $row["username1"]."</td><td>". $row["password"]."</td><td>". $row["last_update"]."</td><td>". $row["picture"]."</td></tr>";
        
    }
    echo "</table>";
}
else{
    echo "0 result";
}

$conn-> close();
?>
</table>
</body>
</html>