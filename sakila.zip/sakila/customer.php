<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
		<link href="css/style.css" rel="stylesheet">
    <title>Table with database</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: blue;
            font-family: monospace;
            font-size: 15.3px;
            text-align:center;
        }
        th{
            
            background-color: black;
            color :white;
            text-align: center;
        }
    </style>
</head>
<STYLE>A{text-decoration:none;}</STYLE>
<body>
<header> 
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
    <div class="container">


	
		
			<nav>
				<ul>
                
                    
					<li><a href="staff_query.php">QUERY</a></li>
					
				
					
					
				</ul>
			</nav>
        </div>
    </header>
<body>


<table>
        <tr>
            <th>customer_id</th>
            <th>store_id</th>
            <th>first_name</th>
            <th>last_name</th>
            <th>email</th>
            <th>address_id</th>
            <th>create_date</th>
            <th>last_update</th>
            <th>active</th>
</tr>
<?php

//create connection
$conn= mysqli_connect("localhost","root","","sakila");

//check connection
if($conn->connect_error){
    die("Connection failed: ".$conn-> connect_error);
}

$sql= "SELECT customer_id,store_id,first_name,last_name,email,address_id,create_date,last_update ,active FROM customer";
$result=$conn-> query($sql);

if($result-> num_rows > 0){
    //output data for each row
    while($row= $result-> fetch_assoc()){
        echo "<tr><td>". $row["customer_id"]. "</td><td>" .$row["store_id"]."</td><td>" .$row["first_name"]."</td><td>".$row["last_name"]."</td><td>" .$row["email"]."</td><td>"  .$row["address_id"]."</td><td>"  .$row["create_date"]."</td><td>"  .$row["last_update"]."</td><td>" .  $row["active"]."</td></tr>";
        
    }
    echo "</table>";
}
else{
    echo "0 result";
}

$conn-> close();
?>
</table>
</body>
</html>