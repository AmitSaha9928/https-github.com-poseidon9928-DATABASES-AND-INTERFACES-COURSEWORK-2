<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
	
    <link href="css/style.css" rel="stylesheet">
    <meta charset=UTF-8">
    <title>Table with database</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: blue;
            font-family: monospace;
            font-size: 17.3px;
            text-align:left;
        }
        th{
            background-color: black;
            color :white;
        }
    </style>
</head>
<STYLE>A{text-decoration:none;}</STYLE>
<body>
<header> 
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
    <div class="container">


	
		
			<nav>
				<ul>
                
                    
					<li><a href="address_query.php">QUERY</a></li>
					
				
					
					
				</ul>
			</nav>
        </div>
    </header>
<table>
        <tr>
            <th>address_id</th>
            <th>address</th>
            <th>address2</th>
            <th>district</th>
            <th>city_id</th>
            <th>postal_code</th>
            <th>phone</th>
            <th>last_update</th>
            
</tr>
<?php

//create connection
$conn= mysqli_connect("localhost","root","","sakila");

//check connection
if($conn->connect_error){
    die("Connection failed: ".$conn-> connect_error);
}

$sql= "SELECT address_id,address,address2,district,city_id,postal_code,phone,last_update FROM address";
$result=$conn-> query($sql);

if($result-> num_rows > 0){
    //output data for each row
    while($row= $result-> fetch_assoc()){
        echo "<tr><td>". $row["address_id"]. "</td><td>".$row["address"]."</td><td>" . $row["address2"]."</td><td>". $row["district"]."</td><td>". $row["city_id"]."</td><td>". $row["postal_code"]."</td><td>".  $row["phone"]."</td><td>".$row["last_update"]."</td></tr>";
        
    }
    echo "</table>";
}
else{
    echo "0 result";
}

$conn-> close();
?>
</table>
</body>
</html>