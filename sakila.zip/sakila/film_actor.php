<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
		<link href="css/style.css" rel="stylesheet">
    <title>Table with database</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: blue;
            font-family: monospace;
            font-size: 17.3px;
            text-align:left;
        }
        th{
            background-color: black;
            color :white;
        }
    </style>
</head>
<STYLE>A{text-decoration:none;}</STYLE>

<body>
<header> 
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
    <div class="container">


	
		
			<nav>
				<ul>
                
                    
					<li><a href="filmactor_query.php">QUERY</a></li>
					
				
					
					
				</ul>
			</nav>
        </div>
    </header>
<table>
        <tr>
            <th>actor_id</th>
            <th>film_id</th>
            <th>last_update</th>
</tr>
<?php

//create connection
$conn= mysqli_connect("localhost","root","","sakila");

//check connection
if($conn->connect_error){
    die("Connection failed: ".$conn-> connect_error);
}

$sql= "SELECT actor_id,film_id,last_update FROM film_actor";
$result=$conn-> query($sql);

if($result-> num_rows > 0){
    //output data for each row
    while($row= $result-> fetch_assoc()){
        echo "<tr><td>". $row["actor_id"]. "</td><td>" .$row["film_id"]."</td><td>" .  $row["last_update"]."</td></tr>";
        
    }
    echo "</table>";
}
else{
    echo "0 result";
}

$conn-> close();
?>
</table>
</body>
</html>