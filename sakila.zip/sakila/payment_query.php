<!DOCTYPE Html>
<html>
       
    <head>
    <link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
		<link href="css/style.css" rel="stylesheet">
        <title>search</title>
</head>
<body>
	
<style>
    .button{
        background-color:#4EC29E;
        border :none;
        color: black;
        margin: 4px 2px;
    }
    label{
        float: left;
        width: 20em;
        text-align: right;
		padding-right: 0em;
        color: brown;
        
	
    }

    input[type=text ]{
        background-color:#91E4E6;
        color: black;  
    }
    input[type=tel ]{
        background-color:#91E4E6;
        color: black;  
    }

    input[type=number ]{
        background-color:#91E4E6;
        color: black;  
    }

    table{
        background-color:black;
        color:blue;
    }

</style>

<?php

    $host="localhost";
    $username="root";
    $password="";
    $database="sakila";

    $payment_id="";
    $customer_id ="";
    $staff_id="";
    $rental_id="";
    $amount="";
    $payment_date="";
    $last_update="";
    

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    


    try{
        $connect = mysqli_connect($host,$username,$password,$database);
    }catch(Exception $ex){
        echo "error";
    }

    function getPosts()
    {
      $posts=array();
      $posts[0]=$_POST['payment_id'];
      $posts[1]=$_POST['customer_id'];
      $posts[2]=$_POST['staff_id'];
      $posts[3]=$_POST['rental_id'];
      $posts[4]=$_POST['amount'];
      $posts[5]=$_POST['payment_date'];
      $posts[6]=$_POST['last_update'];
     
      
      
       return $posts;
    }

    
    



?>
<center>
    
    <form action ="payment_query.php" method="post">
    
    <header>  
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
   </header>
        <br><br>
        <div>
        <label><strong>PAYMENT ID :</strong></label>
        <input type="number" name="payment_id"  value="<?php echo $payment_id;?>"><br><br><br>
        </div>
        <label><strong>CUSTOMER ID :</strong></label>
        <input type="number" name="customer_id"  value="<?php echo $customer_id;?>"><br><br><br>
        </div>
        <div>
        <label><strong>STAFF ID :</strong></label>   
        <input type="number" name="staff_id"  value="<?php echo $staff_id;?>"><br><br><br>
        </div>
        <div>
        <label><strong>RENTAL ID :</strong></label>   
        <input type="number" name="rental_id"  value="<?php echo $rental_id;?>"><br><br><br>
        </div>
        <div>
        <label><strong>AMOUNT :</strong></label>   
        <input type="number" name="amount"  value="<?php echo $amount;?>"><br><br><br>
        </div>
        <div>
        <label><strong>PAYMENT DATE :</strong></label>
        <input type="tel" name="payment_date"  value="<?php echo $payment_date;?>"><br><br><br>
        </div>
        <label><strong>LAST UPDATE :</strong></label>   
        <input type="tel" name="last_update"  value="<?php echo $last_update;?>"> <br><br><br>
        </div>
        
        <div>
            <input type="submit"  class=button name="search" value="SEARCH">
            <input type ="submit"  class=button name="insert" value="INSERT">
            <input type ="submit"  class=button name="delete" value="DELETE">
            <input type ="submit" class=button name="update" value="UPDATE"><br><br><br>
        </div>
       
</form>

</center>
<?php

   //search 
if(isset($_POST['search']   ))
{
    

    $data=getPosts();

    $searchquery="SELECT * FROM `payment` WHERE payment_id=$data[0] ";
    
    
    $search_Result= mysqli_query($connect,$searchquery);
    
    
    if($search_Result)
    {
        if(mysqli_num_rows($search_Result))
        {   
            echo "<br><br><br>";
            echo "<center>";
            echo "<table border=1>";
            
            while($row=mysqli_fetch_array($search_Result))
            {
                
                echo "<tr>";
                echo "<td>";echo "payment id"; echo "</td>";
                echo "<td>"; echo"customer id"; echo "</td>";
                echo "<td>"; echo"staff id"; echo "</td>";
                echo "<td>"; echo"rental id "; echo "</td>";
                echo "<td>"; echo"amount"; echo "</td>";
                echo "<td>"; echo"payment date"; echo "</td>";
                echo "<td>"; echo"last_update"; echo "</td>";
                


               echo "<tr>";
               echo "<td>";echo $row['payment_id']; echo"</td>";
               echo "<td>"; echo $row['customer_id'] ; echo"</td>";
               echo "<td>"; echo $row['staff_id'] ; echo"</td>";
               echo "<td>"; echo $row['rental_id'] ; echo"</td>";
               echo "<td>"; echo $row['amount'] ; echo"</td>";
               echo "<td>";echo $row['payment_date'];  echo"</td>";
               echo "<td>";echo $row['last_update'];  echo"</td>";

                echo"</tr>";
                
               
                
            }
            echo "</table>";
           echo "</center>";
        }else{
            echo "No data for this id";
        }
    }else{
        echo "result error".$ex->getMessage();
    }
}

    //insert
    if(isset($_POST['insert']))
    {
        $data=getPosts();
        $insertquery="INSERT INTO `payment` (`payment_id`,`customer_id`,`staff_id`,`rental_id`,`amount`,`payment_date`,`last_update`) VALUES ('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]')";
        try{
            $insert_Result=mysqli_query($connect,$insertquery);

            if($insert_Result)
            {
                if(mysqli_affected_rows($connect)>0)
                {
                    echo "Data inserted";
                }else{
                    echo "Data not inserted";
                }
            }

        }catch(Exception $ex){
            echo "error insert".$ex->getMessage();
        }
    }

    //insert
    if(isset($_POST['delete']))
    {
        $data=getPosts();
        $deletequery="DELETE FROM `payment` WHERE `payment_id`=$data[0] ";
        try{
            $delete_Result=mysqli_query($connect,$deletequery);

            if($delete_Result)
            {
                if(mysqli_affected_rows($connect)>0)
                {
                    echo "Data deleted";
                }else{
                    echo "Data not deleted";
                }
            }

        }catch(Exception $ex){
            echo "error delete".$ex->getMessage();
        }
    }

    //insert
    if(isset($_POST['update']))
    {
        $data=getPosts();
        $updatequery="UPDATE `payment` SET `payment_id`='$data[0]',`customer_id`='$data[1]',`staff_id`='$data[2]',`rental_id`='$data[3]',`amount`='$data[4]',`payment_date`='$data[5]',`last_update`='$data[6]' WHERE `payment_id`='$data[0]'";
        try{
            $update_Result=mysqli_query($connect,$updatequery);

            if($update_Result)
            {
                if(mysqli_affected_rows($connect)>0)
                {
                    echo "Data updated";
                }else{
                    echo "Data not updated";
                }
            }

        }catch(Exception $ex){
            echo "error update".$ex->getMessage();
        }
    }
    

?>



</body>

</html>


