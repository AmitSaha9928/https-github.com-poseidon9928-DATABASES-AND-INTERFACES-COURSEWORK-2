<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href='https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap' />
	
    <link href="css/style.css" rel="stylesheet">
    <title>Table with database</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: blue;
            font-family: monospace;
            font-size: 17.3px;
            text-align:left;
        }
        th{
            background-color: black;
            color :white;
        }
    </style>
</head>
<STYLE>A{text-decoration:none;}</STYLE>
<body>


<header> 
    <h1 class="logo"><font size="40" color="black"><a href="Mainpage.html">SAKILA</a></font></h1>
    <div class="container">


	
		
			<nav>
				<ul>
                
                    
					<li><a href="city_query.php">QUERY</a></li>
					
				
					
					
				</ul>
			</nav>
        </div>
    </header>

<table>
        <tr>
            <th>city_id</th>
            <th>city</th>
            <th>country_id</th>
            <th>last_update</th>
</tr>
<?php

//create connection
$conn= mysqli_connect("localhost","root","","sakila");

//check connection
if($conn->connect_error){
    die("Connection failed: ".$conn-> connect_error);
}

$sql= "SELECT city_id,city,country_id,last_update FROM city";
$result=$conn-> query($sql);

if($result-> num_rows > 0){
    //output data for each row
    while($row= $result-> fetch_assoc()){
        echo "<tr><td>". $row["city_id"]. "</td><td>".$row["city"]."</td><td>" .$row["country_id"]."</td><td>" .  $row["last_update"]."</td></tr>";
        
    }
    echo "</table>";
}
else{
    echo "0 result";
}

$conn-> close();
?>
</table>
</body>
</html>